🌽 KẾ TOÁN DOANH NGHIỆP - DEMO 0.1

Bản thử nghiệm giao diện có biểu tượng 🌽.

Cách mở: giải nén ZIP, mở index.html bằng Chrome. Nếu muốn cài như app (Add to Home screen), cần đưa thư mục lên hosting HTTPS; file mở cục bộ không bảo đảm cài PWA.

Dữ liệu lưu trong bộ nhớ trình duyệt trên thiết bị. Hãy xuất bản sao lưu JSON thường xuyên.

Chưa phải phần mềm kế toán pháp định, chưa tích hợp hóa đơn điện tử/kê khai thuế/cloud sync.
